<?php
return array (
  'stat' => true,
) ;