<?php
return array (
  'enableClassPathCache' => false,
  'signture' => '1949dc91d18a4fc6b87a00abd9900fc6',
) ;