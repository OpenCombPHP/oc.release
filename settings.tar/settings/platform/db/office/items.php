<?php
return array (
  'dsn' => 'mysql:host=192.168.1.1;dbname=oc2',
  'username' => 'root',
  'password' => '1',
  'options' => 
  array (
    1002 => 'SET NAMES \'utf8\'',
  ),
) ;