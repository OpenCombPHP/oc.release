<?php
return array (
  'config' => 'office',
) ;