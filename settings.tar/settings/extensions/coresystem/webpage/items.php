<?php
return array (
  'title-template' => '%s',
  'description-template' => '%s',
  'keywords-template' => '%s',
  'controlpanel-title-template' => '控制面板 - %s',
  'controlpanel-description-template' => '%s',
  'controlpanel-keywords-template' => '%s',
) ;