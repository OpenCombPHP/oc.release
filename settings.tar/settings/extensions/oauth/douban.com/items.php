<?php
return array (
	'appKey' => '0ceac7905f0c9d9726c056b11d25d8c5' ,
	'appSecret' => 'e4a6e42578079f5d' ,
) ;