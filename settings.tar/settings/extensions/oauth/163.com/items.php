<?php
return array (
	'appKey' => 'EdfhbziNaN0AhD7O' ,
	'appSecret' => '7Rb6klRqF8C5BjBCdfpUPAHYFZ5UsrLK' ,
) ;