<?php
return array (
	'appKey' => 'UWybXWBjpBCMSTYpGsON',
	'appSecret' => '=i6SRj-zxoyQDcUsps)RJLa-Cy*5f=xGCosm50WB' ,
) ;