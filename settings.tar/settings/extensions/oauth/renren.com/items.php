<?php
return array (
	'appKey' => '924c354aabf14119aca95e1d04620ae8' ,
	'appSecret' => 'e504b6e5a79a4584983c37cdc8c32b53' ,
) ;