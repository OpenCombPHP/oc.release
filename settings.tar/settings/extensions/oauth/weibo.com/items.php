<?php
return array (
	'appKey' => '3576764673' ,
	'appSecret' => 'fd186d18e7d2e01367dabdf5d75de8ec' ,
) ;