<?php
return array (
	'appKey' => '801086404' ,
	'appSecret' => '736fdb45d5169fd7c014437630e06c9d' ,
) ;