<?php
return array (
  'installeds' => 
  array (
    0 => 'extensions/coresystem/0.1',
    1 => 'extensions/advanced-component/0.1',
    2 => 'extensions/development-toolkit/0.1',
    5 => 'extensions/opencms/0.1',
    6 => 'extensions/mvc-merger/0.1',
    7 => 'extensions/version-repos-tool/0.1',
    8 => 'extensions/doccenter/0.1',
    9 => 'extensions/friendlyerror/0.1',
    10 => 'extensions/oauth/0.1',
    11 => 'extensions/friends/0.1',
    12 => 'extensions/userstate/0.1',
    13 => 'extensions/comment/0.1',
    14 => 'extensions/oc-wonei-bridge/0.1',
    15 => 'extensions/oauth_userstate_adapter/0.1',
    16 => 'extensions/oauth_friends_adapter/0.1',
  ),
  'enable' => 
  array (
    3 => 
    array (
      0 => 'coresystem',
      1 => 'advancedcomponent',
      2 => 'development-toolkit',
      3 => 'opencms',
      4 => 'mvc-merger',
      5 => 'version-repos-tool',
      6 => 'doccenter',
      7 => 'friendlyerror',
      8 => 'oauth',
      9 => 'friends',
      10 => 'userstate',
      11 => 'comment',
      12 => 'oc-wonei-bridge',
      13 => 'oauth_userstate_adapter',
      14 => 'oauth_friends_adapter',
    ),
    2 => 
    array (
    ),
  ),
) ;