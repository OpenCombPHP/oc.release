<?php
return array (
  'toplist' => 
  array (
    2 => 
    array (
      'index_new' => '1',
      'limit_new' => '10',
      'limit_hot' => '10',
    ),
    3 => 
    array (
      'index_new' => '1',
      'limit_new' => '10',
      'limit_hot' => '10',
    ),
    5 => 
    array (
      'index_new' => '1',
      'limit_new' => '10',
      'limit_hot' => '10',
    ),
    4 => 
    array (
      'index_new' => '1',
      'limit_new' => '10',
      'limit_hot' => '10',
    ),
    1 => 
    array (
      'index_new' => '1',
      'index_hot' => '1',
      'limit_new' => '10',
      'limit_hot' => '10',
    ),
  ),
) ;